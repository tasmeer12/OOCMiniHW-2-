package oocminihw2;

public class Boat extends Vehicle implements Sailable {
    public Boat(String make, String type) {
        this.make = make;
        this.type = type;
        numSails = 1; // Set the number of sails for a boat
    }

    @Override
    public void hoistSail() {
        // Implement the hoistSail() method for a boat
        System.out.println("Hoisting the sail.");
    }

    @Override
    public void lowerSail() {
        // Implement the lowerSail() method for a boat
        System.out.println("Lowering the sail for safety.");
    }

    @Override
    public boolean isSailHoisted() {
        // Implement the isSailHoisted() method for a boat
        return numSails > 0;
    }

    @Override
    public void landHo() {
        // Implement the landHo() method for a boat
        System.out.println("Land ho! We have arrived at our destination.");
    }

    // Implement the remaining methods from the Vehicle class

    // Implement other methods and properties specific to the Boat class
}
