package oocminihw2;

public class Airplane implements Flyable {
    private float speed;
    private float direction;
    private String make;
    private String type;
    private float altitude;

    public Airplane(String make, String type) {
        this.make = make;
        this.type = type;
    }

    @Override
    public void accelerate(float speed) {
        this.speed += speed;
    }

    @Override
    public void brake() {
        this.speed = 0;
    }

    @Override
    public void turn(float angle) {
        this.direction += angle;
    }

    @Override
    public float getDirection() {
        return direction;
    }

    @Override
    public float getSpeed() {
        return speed;
    }

    @Override
    public String getMake() {
        return make;
    }

    @Override
    public String getType() {
        return type;
    }

    @Override
    public void changeAltitude(float change) {
        this.altitude += change;
    }

    @Override
    public float getAltitude() {
        return altitude;
    }
}
