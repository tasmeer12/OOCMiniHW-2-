package oocminihw2;

public class Car implements Drivable {
    private float speed;
    private float direction;
    private String make;
    private String type;

    public Car(String make, String type) {
        this.make = make;
        this.type = type;
    }

    @Override
    public void accelerate(float speed) {
        this.speed += speed;
    }

    @Override
    public void brake() {
        this.speed = 0;
    }

    @Override
    public void turn(float angle) {
        this.direction += angle;
    }

    @Override
    public float getDirection() {
        return direction;
    }

    @Override
    public float getSpeed() {
        return speed;
    }

    @Override
    public String getMake() {
        return make;
    }

    @Override
    public String getType() {
        return type;
    }
}
