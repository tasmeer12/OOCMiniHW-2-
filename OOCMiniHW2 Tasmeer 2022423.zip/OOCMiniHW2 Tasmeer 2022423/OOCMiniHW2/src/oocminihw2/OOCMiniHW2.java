package oocminihw2;

public class OOCMiniHW2 {
    public static void main(String[] args) {
        Car myCar = new Car("Toyota", "Sedan");
        Airplane myAirplane = new Airplane("Boeing", "747");
        Boat myBoat = new Boat("Beneteau", "Sailboat");
        
        System.out.println("Car Make: " + myCar.getMake());
        System.out.println("Car Type: " + myCar.getType());
        System.out.println("Car Speed: " + myCar.getSpeed());
        System.out.println("Airplane Make: " + myAirplane.getMake());
        System. out.println("Airplane Type: " + myAirplane.getType());
        System.out.println("Airplane Speed: " + myAirplane.getSpeed());
        
       
    }
}
