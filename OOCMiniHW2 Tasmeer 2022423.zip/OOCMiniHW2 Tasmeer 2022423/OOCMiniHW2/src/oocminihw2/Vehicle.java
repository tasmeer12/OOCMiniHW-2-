package oocminihw2;

public abstract class Vehicle {
    private float speed;
    private float direction = 0;
    protected String make;
    protected String type; // Change access to protected
    protected int numWheels = 0;
    protected int numWings = 0;
    protected int numSails = 0;
    private int numPassengers;
}
